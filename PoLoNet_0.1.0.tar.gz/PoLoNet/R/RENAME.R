#----------RENAME-----------#
RENAME <- function(varname, EDGE) {
    a <- paste0(varname, EDGE[1], "_", EDGE[2])
    a
}
